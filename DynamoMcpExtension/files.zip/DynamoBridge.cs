// DynamoBridge.cs
// 配置場所の想定: 新規プロジェクト "DynamoMcpExtension" (Dynamo View Extension用)
//
// 役割:
//   Dynamoが起動しグラフが開かれたときに CommandExecutive / CurrentWorkspaceModel を
//   静的に保持しておき、Revit側の commandset から「今開いているDynamoグラフ」に
//   コマンドを送れるようにする橋渡し役。
//
// 注意:
//   Dynamo for Revit と Dynamo for Civil3D はどちらも同じ Dynamo Core をホストしているため、
//   このクラス自体はホストを問わず共通で使えます。
//
// このファイルはDynamoDS/Dynamo公式ソース(RecordableCommands.cs, HomeWorkspaceModel.cs,
// ICommandExecutive.cs等)を実際に参照して構文を検証済みです。

using System;
using Dynamo.Extensions;
using Dynamo.Graph.Nodes;
using Dynamo.Graph.Workspaces;
using Dynamo.Models;

namespace DynamoMcpExtension
{
    /// <summary>
    /// Dynamoの実行中インスタンスへの唯一の参照点。
    /// Revit/Civil3D側のプラグインからはこのシングルトン経由でDynamoを操作する。
    /// </summary>
    public sealed class DynamoBridge
    {
        private static readonly Lazy<DynamoBridge> _instance =
            new Lazy<DynamoBridge>(() => new DynamoBridge());

        public static DynamoBridge Instance => _instance.Value;

        private DynamoBridge() { }

        /// <summary>コマンド実行の入口。ViewExtensionのLoaded()で設定される。</summary>
        public ICommandExecutive CommandExecutive { get; private set; }

        /// <summary>現在開いているワークスペース（グラフ）。</summary>
        public WorkspaceModel CurrentWorkspace { get; private set; }

        /// <summary>Dynamo拡張が読み込まれ、操作可能になっているか。</summary>
        public bool IsReady => CommandExecutive != null && CurrentWorkspace != null;

        /// <summary>拡張のUniqueId/Name。ExecuteCommand呼び出し時に必要。</summary>
        public string ExtensionUniqueId { get; internal set; }
        public string ExtensionName { get; internal set; }

        internal void Attach(ICommandExecutive executive, WorkspaceModel workspace)
        {
            CommandExecutive = executive;
            CurrentWorkspace = workspace;
        }

        internal void UpdateWorkspace(WorkspaceModel workspace)
        {
            CurrentWorkspace = workspace;
        }

        internal void Detach()
        {
            CommandExecutive = null;
            CurrentWorkspace = null;
        }

        // ------------------------------------------------------------------
        // ここから先は commandset 側から呼び出す想定の高レベルAPI例。
        // 実際のノード生成には対象ノードのConcreteType(完全修飾クラス名)が必要。
        // 事前に Dynamo の Search API 等でノードモデルのインスタンスを
        // 作ってから CreateNodeCommand に渡す形になる点に注意。
        // ------------------------------------------------------------------

        public Guid CreateNode(NodeModel node, double x, double y)
        {
            if (!IsReady) throw new InvalidOperationException("Dynamo not ready. Open a graph first.");

            CommandExecutive.ExecuteCommand(
                new DynamoModel.CreateNodeCommand(node, x, y, true, false),
                ExtensionUniqueId,
                ExtensionName);

            return node.GUID;
        }

        public void Connect(Guid startNodeId, int startPortIndex, Guid endNodeId, int endPortIndex)
        {
            if (!IsReady) throw new InvalidOperationException("Dynamo not ready. Open a graph first.");

            // MakeConnectionCommand は Begin(出力ポートから開始) → End(入力ポートで終了) の
            // 2段階で呼ぶ必要がある（ユーザーがワイヤーをドラッグする操作と同じ経路）。
            // PortType は Dynamo.Graph.Nodes 名前空間 (Dynamo.Graph.Connectors ではない)。
            CommandExecutive.ExecuteCommand(
                new DynamoModel.MakeConnectionCommand(
                    startNodeId, startPortIndex, PortType.Output,
                    DynamoModel.MakeConnectionCommand.Mode.Begin),
                ExtensionUniqueId, ExtensionName);

            CommandExecutive.ExecuteCommand(
                new DynamoModel.MakeConnectionCommand(
                    endNodeId, endPortIndex, PortType.Input,
                    DynamoModel.MakeConnectionCommand.Mode.End),
                ExtensionUniqueId, ExtensionName);
        }

        public void SetNodeValue(Guid nodeId, string value)
        {
            if (!IsReady) throw new InvalidOperationException("Dynamo not ready. Open a graph first.");

            // UpdateModelValueCommand(Guid modelGuid, string name, string value) を使用。
            // ExtensionUniqueIdはここでは不要（ExecuteCommand呼び出し時にのみ使う）。
            CommandExecutive.ExecuteCommand(
                new DynamoModel.UpdateModelValueCommand(nodeId, "Value", value),
                ExtensionUniqueId, ExtensionName);
        }

        public void DeleteNode(Guid nodeId)
        {
            if (!IsReady) throw new InvalidOperationException("Dynamo not ready. Open a graph first.");

            CommandExecutive.ExecuteCommand(
                new DynamoModel.DeleteModelCommand(nodeId),
                ExtensionUniqueId, ExtensionName);
        }

        // ------------------------------------------------------------------
        // 推奨ルート: Code Block Node経由でDesignScriptコードを直接実行する。
        // 個々のノード型(NodeModel)を型名から動的生成するより遥かに単純で、
        // "Point.ByCoordinates(x,y,z);" のような任意のDesignScript式をそのまま
        // 1ノードとして配置できる。
        //
        // EngineControllerは WorkspaceModel ではなく HomeWorkspaceModel (そのサブクラス)
        // にのみ存在するため、キャストして取得する。カスタムノード編集中など
        // ホームワークスペースでない場合はnullになるため、その場合は例外を出す。
        // ------------------------------------------------------------------
        public Guid CreateCodeBlockNode(string designScriptCode, double x, double y)
        {
            if (!IsReady) throw new InvalidOperationException("Dynamo not ready. Open a graph first.");

            var homeWorkspace = CurrentWorkspace as HomeWorkspaceModel;
            if (homeWorkspace == null || homeWorkspace.EngineController == null)
                throw new InvalidOperationException(
                    "Current workspace has no EngineController available (are you in a Custom Node editor instead of the home graph?).");

            var cbn = new CodeBlockNodeModel(
                designScriptCode,
                Guid.NewGuid(),
                x, y,
                homeWorkspace.EngineController.LibraryServices,
                CurrentWorkspace.ElementResolver);

            CommandExecutive.ExecuteCommand(
                new DynamoModel.CreateNodeCommand(cbn, x, y, true, false),
                ExtensionUniqueId, ExtensionName);

            return cbn.GUID;
        }
    }
}
