// DynamoMcpExtension.cs
// 配置場所の想定: 新規プロジェクト "DynamoMcpExtension"
//
// IViewExtensionではなく IExtension を実装する版。
// Dynamoの「パッケージ」機構経由で読み込むため、管理者権限なしで
// ユーザーのAppDataフォルダから読み込める（Program Files配下への配置が不要になる）。
//
// ライフサイクル: Startup(StartupParams) → Ready(ReadyParams) → Shutdown()
// ReadyParamsからCommandExecutiveとCurrentWorkspaceModelを取得できる点はViewLoadedParamsと同じ。

using Dynamo.Extensions;
using Dynamo.Graph.Workspaces;

namespace DynamoMcpExtension
{
    public class DynamoMcpExtensionMain : IExtension
    {
        public string UniqueId => "8f3c2e10-9b4a-4c7e-8b2d-1a2b3c4d5e6f";
        public string Name => "Dynamo MCP Bridge";

        public void Startup(StartupParams sp)
        {
            // Dynamo起動開始時。まだワークスペースは使えない場合がある。
        }

        public void Ready(ReadyParams p)
        {
            DynamoBridge.Instance.ExtensionUniqueId = UniqueId;
            DynamoBridge.Instance.ExtensionName = Name;
            // p.CurrentWorkspaceModel は IWorkspaceModel 型なので WorkspaceModel にキャストする
            DynamoBridge.Instance.Attach(p.CommandExecutive, p.CurrentWorkspaceModel as WorkspaceModel);

            // グラフが切り替わった場合に追従する
            p.CurrentWorkspaceChanged += (workspace) =>
            {
                DynamoBridge.Instance.UpdateWorkspace(workspace as WorkspaceModel);
            };
        }

        public void Shutdown()
        {
            DynamoBridge.Instance.Detach();
        }

        public void Dispose()
        {
            DynamoBridge.Instance.Detach();
        }
    }
}
